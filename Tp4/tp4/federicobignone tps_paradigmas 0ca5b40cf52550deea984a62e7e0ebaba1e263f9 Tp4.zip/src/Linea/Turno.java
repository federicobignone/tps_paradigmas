package Linea;

public abstract class Turno {
    public boolean esAzul() {
        return false;
    }

    public boolean esRojo() {
        return false;
    }
}
