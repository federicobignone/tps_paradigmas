package Linea;

import java.util.ArrayList;

public abstract class VarianteDeTriunfo {
    public boolean hayLinea(ArrayList<ArrayList<Character>> tablero) {
        return false;
    }


}
