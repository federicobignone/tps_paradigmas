package Linea;

public class TurnoRojo extends Turno{
}
