package Linea;

public class VarianteA extends VarianteDeTriunfo {





}
