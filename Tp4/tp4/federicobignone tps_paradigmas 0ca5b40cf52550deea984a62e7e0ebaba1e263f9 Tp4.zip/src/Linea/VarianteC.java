package Linea;

public class VarianteC extends VarianteDeTriunfo{
}
