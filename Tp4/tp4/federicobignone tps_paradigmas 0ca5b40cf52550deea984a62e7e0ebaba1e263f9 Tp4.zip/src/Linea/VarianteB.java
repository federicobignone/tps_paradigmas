package Linea;

public class VarianteB extends VarianteDeTriunfo{
}
