package Linea;

public class TurnoAzul extends Turno{
}
